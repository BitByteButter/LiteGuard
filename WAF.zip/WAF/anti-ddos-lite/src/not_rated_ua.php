<?php

global $notRatedUa;
$notRatedUa = array(
    'CleanTalk Uptime bot.+',
    '.*Googlebot.*',
    '.*Bingbot.*',
    '.*Baiduspider.*',
    '.*YandexBot.*',
    '.*facebot.*',
    'facebookexternalhit\/1\.1 \(\+http:\/\/www\.facebook\.com\/externalhit_uatext\.php\)',
    '.*ia_archiver.*',
    '.*UptimeRobot.*'
);
