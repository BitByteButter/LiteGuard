# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| DEV     | :white_check_mark: |

## Reporting a Vulnerability

Fee free to report a security issue to welcome@cleantalk.org.
