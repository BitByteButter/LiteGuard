<?php

namespace Cleantalk\CleantalkAntiDdosLite;

class CleantalkAntiDdosLite
{
    public static function init()
    {
        require_once 'anti-ddos-lite.php';
    }
}
